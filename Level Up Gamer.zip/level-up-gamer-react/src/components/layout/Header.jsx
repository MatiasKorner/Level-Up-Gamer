export default function Header() {
  return (
    <header className="container py-3">
      <p>Header temporal</p>
    </header>
  );
}
