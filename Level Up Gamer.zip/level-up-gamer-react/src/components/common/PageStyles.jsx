
import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

const estilosPorRuta = {
  '/': [
    '/vendor/bootstrap.min.css',
    '/estilos/base.css',
    '/estilos/componentes.css',
    '/estilos/inicio.css',
    '/css/pie.css',
  ],
  '/catalogo': [
    '/vendor/bootstrap.min.css',
    '/estilos/base.css',
    '/estilos/componentes.css',
    '/estilos/inicio.css',
    '/estilos/catalogo.css',
    '/css/pie.css',
  ],
  '/detalle': [
    '/vendor/bootstrap.min.css',
    '/estilos/base.css',
    '/estilos/componentes.css',
    '/estilos/inicio.css',
    '/estilos/detalle.css',
  ],
  '/carrito': [
    '/vendor/bootstrap.min.css',
    '/css/estilos.css',
    '/css/compras.css',
    '/estilos/base.css',
    '/estilos/componentes.css',
    '/estilos/inicio.css',
  ],
  '/pago': [
    '/vendor/bootstrap.min.css',
    '/css/estilos.css',
    '/css/compras.css',
  ],
  '/confirmacion': [
    '/vendor/bootstrap.min.css',
    '/css/estilos.css',
    '/css/compras.css',
  ],
  '/login': [
    '/vendor/bootstrap.min.css',
    '/css/estilos.css',
    '/css/login.css',
  ],
  '/registro': [
    '/estilos/base.css',
    '/estilos/componentes.css',
    '/estilos/auth.css',
  ],
  '/perfil': [
    '/vendor/bootstrap.min.css',
    '/css/estilos.css',
    '/css/cuenta.css',
    '/estilos/base.css',
    '/estilos/componentes.css',
    '/estilos/inicio.css',
  ],
  '/pedidos': [
    '/vendor/bootstrap.min.css',
    '/css/estilos.css',
    '/css/cuenta.css',
  ],
  '/puntos': [
    '/vendor/bootstrap.min.css',
    '/css/estilos.css',
    '/css/cuenta.css',
  ],
  '/blog': [
    '/vendor/bootstrap.min.css',
    '/estilos/base.css',
    '/estilos/componentes.css',
    '/css/blog.css',
    '/estilos/inicio.css',
  ],
  '/articulo': [
    '/vendor/bootstrap.min.css',
    '/css/articulo.css',
  ],
  '/soporte': [
    '/vendor/bootstrap.min.css',
    '/css/support.css',
    '/estilos/base.css',
    '/estilos/componentes.css',
    '/estilos/inicio.css',
  ],
  '/admin': [
    '/estilos/base.css',
    '/css/admin.css',
  ],
  '/404': [
    '/vendor/bootstrap.min.css',
    '/css/error.css',
  ],
};

export default function PageStyles() {
  const { pathname } = useLocation();

  useEffect(() => {
    const archivos = estilosPorRuta[pathname] ?? estilosPorRuta['/404'];

    document
      .querySelectorAll('link[data-lug-page-style]')
      .forEach((link) => link.remove());

    archivos.forEach((href) => {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = href;
      link.dataset.lugPageStyle = 'true';
      document.head.appendChild(link);
    });

    const usaBootstrap = archivos.some((href) =>
      href.startsWith('/vendor/bootstrap.')
    );

    if (
      usaBootstrap &&
      !document.querySelector('script[data-lug-bootstrap]')
    ) {
      const script = document.createElement('script');
      script.src = '/vendor/bootstrap.bundle.min.js';
      script.dataset.lugBootstrap = 'true';
      document.body.appendChild(script);
    }

    return () => {
      document
        .querySelectorAll('link[data-lug-page-style]')
        .forEach((link) => link.remove());
    };
  }, [pathname]);

  return null;
}
